def get_root_path():
    return "/home/eric/Code/dcc_ito_combined/"


if __name__ == "__main__":
    print(get_root_path())
